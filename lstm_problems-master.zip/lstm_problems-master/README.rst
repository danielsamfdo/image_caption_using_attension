=============
LSTM Problems
=============

Suite of toy problems which can test whether a model can learn long-term dependencies.
