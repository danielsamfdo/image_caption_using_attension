""" Suite of toy problems which can test whether a model can learn long-term
dependencies.
"""

from lstm_problems import *

__version__ = "0.0.0"
